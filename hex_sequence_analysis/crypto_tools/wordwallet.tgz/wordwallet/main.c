/* Wordwallet
 * Written in 2012 by
 *   Andrew Poelstra <apoelstra@wpsoftware.net>
 *
 * To the extent possible under law, the author(s) have dedicated all
 * copyright and related and neighboring rights to this software to
 * the public domain worldwide. This software is distributed without
 * any warranty.
 *
 * You should have received a copy of the CC0 Public Domain Dedication
 * along with this software.
 * If not, see <http://creativecommons.org/publicdomain/zero/1.0/>.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <openssl/ec.h>
#include <openssl/sha.h>
#include <openssl/ripemd.h>
#include <openssl/ecdsa.h>
#include <openssl/obj_mac.h>
#include <openssl/evp.h>

#include "list1.h"

#define N_ROUNDS 10000000

static const char *b58_charset = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

/*! \brief Main Base58 + checksum function */
char *base58_check (const unsigned char *buf, int addr_size)
{
  unsigned char hash[32];
  unsigned char hash1[32];
  int size_slop, idx, i;
  unsigned char *buf_cpy = malloc (addr_size + 4);
  char *rv;

  BN_CTX *bnctx = BN_CTX_new ();
  BIGNUM bn_58, bn_quot, bn_rem, bn_key;

  BN_init (&bn_58);
  BN_init (&bn_quot);
  BN_init (&bn_rem);
  BN_init (&bn_key);
  BN_set_word (&bn_58, 58);

  /* Tack on 4 characters of SHA(SHA(addr)) as checksum */
  SHA256 (buf, addr_size, hash);
  SHA256 (hash, sizeof hash, hash1);
  memcpy (&buf_cpy[0], buf, addr_size);
  memcpy (&buf_cpy[addr_size], hash1, 4);

  /* Base-58 the thing, backwards for endianness reasons */
  size_slop = addr_size * 2 + 1;
  rv = malloc (size_slop);
  if (rv == NULL) return NULL;

  idx = size_slop - 1;
  rv[--idx] = 0;
  BN_bin2bn (buf_cpy, addr_size + 4, &bn_key);
  while (!BN_is_zero (&bn_key))
    {
      BN_div (&bn_quot, &bn_rem, &bn_key, &bn_58, bnctx);
      BN_swap (&bn_quot, &bn_key);
      rv[--idx] = b58_charset[BN_get_word (&bn_rem)];
    }
  /* Don't forget the leading zeros! */
  for (i = 0; buf_cpy[i] == 0; ++i)
    rv[--idx] = b58_charset[0];

  /* Shift, since we built the string from the end and
   * probably overestimated the amount of space we have. */
  memmove (&rv[0], &rv[idx], size_slop - idx);

  /* Cleanup */
  BN_clear_free(&bn_58);
  BN_clear_free(&bn_quot);
  BN_clear_free(&bn_rem);
  BN_clear_free(&bn_key);
  BN_CTX_free (bnctx);
  free (buf_cpy);

  return rv;
}

/*! \brief Base58 wrapper for bitcoin addresses */
char *base58_address (const EC_POINT *key, const EC_GROUP *group)
{
  unsigned char address[21];  /* '1' + 160-bit hash */
  unsigned char ec_buf[128];
  unsigned char hash[32];
  int addr_size = EC_POINT_point2oct(group, key,
                                     POINT_CONVERSION_UNCOMPRESSED,
                                     ec_buf, sizeof ec_buf, NULL);

  /* Turn pubkey into address (prefixed by 0 for bitcoin) */
  memset (address, 0, sizeof address);
  SHA256 (ec_buf, addr_size, hash);
  RIPEMD160 (hash, sizeof hash, &address[1]);

  return base58_check (address, sizeof address);
}

/*! \brief Base58 wrapper for privkey */
char *base58_privkey (const EC_KEY *key)
{
  unsigned char ec_buf[128];
  const BIGNUM *bn_key = EC_KEY_get0_private_key (key);

  memset (ec_buf, 0, sizeof ec_buf);
  ec_buf[0] = 128;
  BN_bn2bin (bn_key, &ec_buf[33 - BN_num_bytes (bn_key)]);

  return base58_check (ec_buf, 33);
}

/*! \brief Entry point */
int main (int argc, const char *argv[])
{
  const char *random_words[6];
  const char **key_words;
  int n_key_words;

  printf ("Built with " OPENSSL_VERSION_TEXT "\n");

  /* Obtain words.*/
  if (argc > 1)
    {
      /* Print warning about low entropy */
      printf ("WARNING: If you thought of these words with your own head,\n"
              "         you're in for a world of trouble. Just run %s.\n",
              argv[0]);

      key_words = &argv[1];
      n_key_words = argc - 1;
    }
  else
    {
      BIGNUM bn_n_words;

      BN_init (&bn_n_words);
      BN_set_word (&bn_n_words, N_WORDS);

      printf ("Compiled with %d words.\n\n", N_WORDS);

      printf ("  Words: ");
      for (n_key_words = 0; n_key_words < 6; ++n_key_words)
        {
          BIGNUM bn_idx;
          BN_init (&bn_idx);

          if (!BN_rand_range (&bn_idx, &bn_n_words))
            {
              fputs ("We seem to be out of entropy.\n", stderr);
              exit(0);
            }
          random_words[n_key_words] = words[BN_get_word (&bn_idx)];
          printf ("%s ", random_words[n_key_words]);
          BN_clear_free (&bn_idx);
        }
      puts ("");
      key_words = random_words;

      BN_clear_free (&bn_n_words);
    }

  /* Turn words into keypair */
  {
    int i, j;
    unsigned int md_len;
    unsigned char word_hash[EVP_MAX_MD_SIZE];
    char *tmp;
    BIGNUM *word_hash_bn;
    EC_POINT *pubkey;

    EC_KEY *key = EC_KEY_new_by_curve_name (NID_secp256k1);
    EVP_MD_CTX *mdctx = EVP_MD_CTX_create();

    /* Hash all the words together */
    EVP_DigestInit_ex(mdctx, EVP_sha256(), NULL);
    for (j = 0; j < N_ROUNDS; ++j)
      for (i = 0; i < n_key_words; ++i)
        EVP_DigestUpdate (mdctx, key_words[i], strlen(key_words[i]));
    EVP_DigestFinal_ex(mdctx, word_hash, &md_len);
    EVP_MD_CTX_destroy(mdctx);

    /* Produce keypair */
    word_hash_bn = BN_bin2bn (word_hash, md_len, NULL);

    if (!EC_KEY_set_private_key (key, word_hash_bn))
      {
        fputs ("Failed to set private key.\n", stderr);
        return EXIT_FAILURE;
      }

    pubkey = EC_POINT_new (EC_KEY_get0_group (key));
    if (pubkey == NULL)
      {
        fputs ("Failed to create EC point.\n", stderr);
        return EXIT_FAILURE;
      }

    if (!EC_POINT_mul(EC_KEY_get0_group (key), pubkey, word_hash_bn, NULL, NULL, NULL))
      {
        fputs ("Failed to EC multiply.\n", stderr);
        return EXIT_FAILURE;
      }

    if (!EC_KEY_set_public_key (key, pubkey))
      {
        fputs ("Failed to set public key.\n", stderr);
        return EXIT_FAILURE;
      }

    /* Output */
    tmp = base58_address (pubkey, EC_KEY_get0_group (key));
    printf ("Address: %s\n", tmp);
    free (tmp);

    tmp = base58_privkey (key);
    printf ("Privkey: %s\n", tmp);
    free (tmp);

    /* Cleanup */
    BN_free (word_hash_bn);
    EC_POINT_free (pubkey);
    EC_KEY_free (key);
  }

  return 0;
}

